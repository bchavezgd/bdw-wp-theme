<!-- footer -->
<footer id="footer">
	<p>
		&copy; Copyright <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>. All rights Reserved
	</p>
</footer>

<?php wp_footer(); ?>
</div><!-- end wrapper -->
</body>
</html>
<!-- end footer -->