alert(
	'Surprise Mother Fucker!'
);

var e = 10;